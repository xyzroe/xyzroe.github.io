#!/usr/bin/env python

from http.server import BaseHTTPRequestHandler, HTTPServer

import telebot
import pyodbc
import wget
from urllib.request import urlopen
import urllib.request
import base64


import codecs
with codecs.open('config', 'r', encoding='utf-8') as f:
    exec(f.read())

telebot = telebot.TeleBot(tele_token)


def send_alarm(text):
#    telebot.send_message(manual_tele_rsv, text)
    telebot.send_photo(chat_id=manual_tele_rsv, photo=open('temp.jpg', 'rb'), caption=text)





class testHTTPServer_RequestHandler(BaseHTTPRequestHandler):


  def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type','text/html')
        self.end_headers()
        path = self.path

        dir = path.split('/')

        msg_text = ""
        print(dir[1])
        if (int(dir[1]) > 0):
            switcher = {
                1: "Пост 2 | Турникет ВХОД вручную",
                2: "Пост 2 | Турникет ВЫХОД вручную",
                3: "Пост 2 | Дверь улица вручную",
                4: "Пост 2 | Ворота улица вручную",
                5: "Пост 2 | Роллеты улица вручную"
            }
            url_switcher = {
                1: 'http://192.168.2.74/Streaming/channels/1/picture',
                2: 'http://192.168.2.74/Streaming/channels/1/picture',
                3: 'http://192.168.2.74/Streaming/channels/1/picture',
                4: 'http://192.168.2.72/Streaming/channels/1/picture',
                5: 'http://192.168.2.87/Streaming/channels/1/picture'
            }
            download_url = url_switcher.get(int(dir[1]))
            user_switcher = {
                1: 'view:ViewView1234',
                2: 'view:ViewView1234',
                3: 'view:ViewView1234',
                4: 'view:ViewView1234',
                5: 'view123:ViewView1234'
            }
            credentials = user_switcher.get(int(dir[1]))
            out_file_path = "./temp.jpg"
            req = urllib.request.Request(download_url)
            encoded_credentials = base64.b64encode(credentials.encode('ascii'))
            req.add_header('Authorization', 'Basic %s' % encoded_credentials.decode("ascii"))
            with urllib.request.urlopen(req) as response, open(out_file_path, 'wb') as out_file:
                data = response.read()
                out_file.write(data)
            print(switcher.get(int(dir[1])))
            send_alarm(switcher.get(int(dir[1])));
        return

def run():
  print('starting server...')
  server_address = ('127.0.0.1', 8081)
  httpd = HTTPServer(server_address, testHTTPServer_RequestHandler)
  print('running server...')
  httpd.serve_forever()


run()
