#!/bin/bash
export SCREENDIR=~/.screen
export DISPLAY=:0
cd /home/user1/AlcoPost/
screen -dmS kiosk python3 alcotester.py
screen -dmS server python3 report_server.py
