#! /usr/bin/env python
# coding: utf-8
# zone id = 9
# ctr id = 21 - enter, 22 - exit
# add string to att_log table
# verify_mode - 0 - ok, 1 - alcogol
      #[ID] - auto
      #[zone_id] - 9
      #[ctr_id] - 21 or 22
      #[employee_id] - id
      #[verify_mode] - 20 - ok, 21 - alcogol
      #[direction] - 0
      #[date] - now
token_web_app = 'xA2cDpjx64X5s98eYUgRMW2P5aY5KfVUsYUYygRx'

from http.server import BaseHTTPRequestHandler, HTTPServer

import serial
import pyodbc
import smtplib
import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from tkinter import *
from PIL import Image, ImageTk
import requests

import random
import time
from threading import Thread

import codecs
with codecs.open('config', 'r', encoding='utf-8') as f:
    exec(f.read())

import telebot

telebot = telebot.TeleBot(tele_token)

class MyThreadWeb(Thread):
    def __init__(self, name):
        """Инициализация потока"""
        Thread.__init__(self)
        self.name = name

    def run(self):
        """Запуск потока"""
        make_default_tk()
        read_data()

class MyThreadApp(Thread):
    def __init__(self, name):
        """Инициализация потока"""
        Thread.__init__(self)
        self.name = name

    def run(self):
        """Запуск потока"""
        runWeb()


class testHTTPServer_RequestHandler(BaseHTTPRequestHandler):


  def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type','text/html')
        self.end_headers()
        path = self.path
        dir = path.split('/')
        print(dir)
        if dir[1] == token_web_app:
            if dir[2] == '1':
                send_open_cmd_enter();
            if dir[2] == '2':
                send_open_cmd_exit();
        return

def runWeb():
  print('starting server...')
  server_address = ('', 8085)
  httpd = HTTPServer(server_address, testHTTPServer_RequestHandler)
  print('running server...')
  httpd.serve_forever()


def write_to_db(gate, id, result):
    driver = sql_driver
    server = sql_server
    port = sql_port
    db = sql_db
    user = sql_user
    pw = sql_pw
    conn_str = ';'.join([driver, server, port, db, user, pw])
    conn = pyodbc.connect(conn_str)
    cursor = conn.cursor()
    sql_comm = '''INSERT INTO [access].[dbo].[Att_log] ([zone_id],[ctr_id],[employee_id],[verify_mode],[direction])
                  OUTPUT INSERTED.[ID]
                  VALUES (9, {}, {}, {}, 0)'''.format(gate, id, result)
    cursor.execute(sql_comm)
    result = cursor.fetchone()
    cursor.commit()
    cursor.close()
    print(result)
    return 1

def read_from_db(id):
    driver = sql_driver
    server = sql_server
    port = sql_port
    db = sql_db
    user = sql_user
    pw = sql_pw
    conn_str = ';'.join([driver, server, port, db, user, pw])
    conn = pyodbc.connect(conn_str)
    cursor = conn.cursor()
    sql_comm = '''SELECT [surname], [firstname], [middlename], [photo], [vip]
                  FROM [access].[dbo].[Employees]
                  WHERE [ID] = {}'''.format(id)
    cursor.execute(sql_comm)
    result = cursor.fetchone()
    if result is None:
        alien_report(id)
        return "Пользователь", "не", "зарегистрирован", '/'+default_img, 0
    else:
        result[3] = default_img if not result[3] else result[3]
        return result[0], result[1], result[2], '/'+result[3], result[4]


def open_turnstile(dir):
    print("VIP")
    time.sleep(2)
    if dir == 1:
        ser.write(b'OPEN|1\n')
        print("open_enter_turnstile")
    if dir == 2:
        ser.write(b'OPEN|2\n')
        print("open_exit_turnstile")

def make_report(id, gate):
    if gate == '1':
        msg_text = full_name1 + mail_text_enter
    if gate == '2':
        msg_text = full_name2 + mail_text_exit
    telebot.send_message(alco_tele_rsv, msg_text)
    try:
        photo = open(path_to_photo_db + '/' + id + '.jpg', 'rb')
        telebot.send_photo(alco_tele_rsv, photo)
    except FileNotFoundError:
        photo = open('./blank.jpg', 'rb')

def alien_report(id):
    url = 'https://api.telegram.org/bot'+ tele_token +'/sendMessage?chat_id='+ tele_rsv +'&text=👽 *Post 2* Alien id ' + str(id) + '&parse_mode=markdown'
    data = requests.get(url).json

def send_open_cmd_enter():
    ser.write(b'OPEN|1\n')
    url = 'http://localhost:8081/1'
    data = requests.get(url).json
    print("manual_send_open_cmd_enter_turnstile")

def send_open_cmd_exit():
    ser.write(b'OPEN|2\n')
    url = 'http://localhost:8081/2'
    data = requests.get(url).json
    print("manual_send_open_cmd_exit_turnstile")

def send_open_cmd_door():
    ser.write(b'OPEN|3\n')
    #url = 'http://localhost:8081/3'
    #data = requests.get(url).json
    print("manual_send_open_cmd_door")

def send_open_cmd_vorota():
    ser.write(b'OPEN|4\n')
    url = 'http://localhost:8081/4'
    data = requests.get(url).json
    print("manual_send_open_cmd_vorota")

def make_default_tk():
    global button_dir1, button_dir2, button_img1, button_img2, button_name1, button_name2, button_stat1, button_stat2, button_exit, button_enter, button_door, button_street_text
    global frame1, frame2, img1, img2, photo1, photo2, frame3, frame0, frame4, button_vorota, frame_b1, frame_b2, frame_b0

    frame0 = Frame(root)
    frame0.grid(row=0, column=0)
    frame0.pack()
    frame1, frame2, frame4 = Frame(frame0), Frame(frame0), Frame(frame0, width = 200)
    frame3 = Frame(root)
    frame1.pack(side = LEFT, expand=1)
    frame4.pack(side = LEFT)
    frame2.pack(side = LEFT, expand=1)
    frame3.pack()
    frame_b0 = Frame(frame3)
    frame_b1 = Frame(frame3, bg='#ff930f')
    frame_b2 = Frame(frame3, bg='#00a01a')
    frame_b0.pack()
    frame_b1.pack()
    frame_b2.pack()

    button_dir1 = Label(frame1, text='ВХОД', font='Helvetica 22 bold')
    button_dir2 = Label(frame2, text='ВЫХОД', font='Helvetica 22 bold')
    button_dir1.pack(padx=10, pady=0)
    button_dir2.pack(padx=10, pady=0)

    img1, img2 = Image.open(default_img), Image.open(default_img)
    img1.thumbnail((338, 450), Image.ANTIALIAS)
    img2.thumbnail((338, 450), Image.ANTIALIAS)
    photo1, photo2 = ImageTk.PhotoImage(img1), ImageTk.PhotoImage(img2)
    button_img1, button_img2 = Label(frame1, image=photo1), Label(frame2, image=photo2)
    button_img1.pack(padx=5, pady=5)
    button_img2.pack(padx=5, pady=5)

    button_name1 = Label(frame1, text=default_name, font='Helvetica 18 bold')
    button_name2 = Label(frame2, text=default_name, font='Helvetica 18 bold')
    button_stat1 = Label(frame1, text=default_stat, font='Helvetica 18')
    button_stat2 = Label(frame2, text=default_stat, font='Helvetica 18')
    button_name1.pack(padx=10, pady=10)
    button_name2.pack(padx=10, pady=10)
    button_stat1.pack(padx=5, pady=5)
    button_stat2.pack(padx=5, pady=5)


    button_street_text = Label(frame_b0, text='Ручное открывание', font='Helvetica 16 bold')
    button_street_text.pack(side = BOTTOM, padx=20, pady=5)
    button_enter = Button(frame_b1, text='Вход', width=25, command=send_open_cmd_enter, font='Helvetica 16')
    button_exit = Button(frame_b1, text='Выход', width=25, command=send_open_cmd_exit, font='Helvetica 16')
#    button_door = Button(frame_b2, text='Дверь', width=25, command=send_open_cmd_door, font='Helvetica 16')
#    button_vorota = Button(frame_b2, text='Ворота', width=25, command=send_open_cmd_vorota, font='Helvetica 16')
    button_enter.pack(side = LEFT, padx=15, pady=9)
    button_exit.pack(side = LEFT, padx=15, pady=9)
#    button_door.pack(side = LEFT, padx=15, pady=9)
#    button_vorota.pack(side = LEFT, padx=15, pady=9)

def alert_default():
    global button_img1, button_img2, button_name1, button_name2, button_stat1, button_stat2
    global img1, img2, photo1, photo2

    button_name1.config(text=default_name)
    button_name2.config(text=default_name)
    button_stat1.config(text=default_stat, fg='black', font='Helvetica 18')
    button_stat2.config(text=default_stat, fg='black', font='Helvetica 18')

    img1, img2 = Image.open(default_img).resize((338, 450)), Image.open(default_img).resize((338, 450))
    photo1, photo2 = ImageTk.PhotoImage(img1), ImageTk.PhotoImage(img2)
    button_img1.config(image=photo1)
    button_img2.config(image=photo2)

def alert(dir, id, stat):
    def alert_exit(id, stat):
        global button_stat2
        if stat == '1':
            global button_img2, button_name2, img2, photo2, ex_inc, full_name2, photo_s2
            surname, firstname, middlename, photo_path, vip = read_from_db(id)
            full_name2 = surname + ' ' + firstname + ' ' + middlename
            photo_s2 = path_to_photo_db + photo_path
            button_name2.config(text=full_name2)

            try:
                img2 = Image.open(path_to_photo_db + photo_path).resize((338, 450))
            except FileNotFoundError:
                img2 = Image.open(default_img).resize((338, 450))
            photo2 = ImageTk.PhotoImage(img2)
            button_img2.config(image=photo2)

            button_stat2.config(text=stat_dict[stat], fg='black')
            #if vip == False: ###True
            open_turnstile(2)
            button_stat2.config(text=stat_dict['5'])
            button_stat2.config(fg='green')
            write_to_db('22', id, '2')
        else:
            button_stat2.config(text=stat_dict[stat])

        if stat == '4':
            button_stat2.config(fg='red')
            write_to_db('22', id, '1')
            make_report(id, '2')

        elif stat == '5':
            button_stat2.config(fg='green')
            write_to_db('22', id, '0')

    def alert_enter(id, stat):
        global button_stat1
        if stat == '1':
            global button_img1, button_name1, img1, photo1, ent_inc, full_name1, photo_s1
            surname, firstname, middlename, photo_path, vip = read_from_db(id)
            full_name1 = surname + ' ' + firstname + ' ' + middlename
            photo_s1 = path_to_photo_db + photo_path
            button_name1.config(text=full_name1)

            try:
                img1 = Image.open(path_to_photo_db + photo_path).resize((338, 450))
            except FileNotFoundError:
                img1 = Image.open(default_img).resize((338, 450))
            photo1 = ImageTk.PhotoImage(img1)
            button_img1.config(image=photo1)

            button_stat1.config(text=stat_dict[stat], fg='black')
            #if vip == False:
            open_turnstile(1)
            button_stat1.config(text=stat_dict['5'])
            button_stat1.config(fg='green')
            write_to_db('21', id, '2')
        else:
            button_stat1.config(text=stat_dict[stat])

        if stat == '4':
            button_stat1.config(fg='red')
            write_to_db('21', id, '1')
            make_report(id, '1')

        elif stat == '5':
            button_stat1.config(fg='green')
            write_to_db('21', id, '0')

    if dir == 'EXIT':
        alert_exit(id, stat)
    if dir == 'ENTER':
        alert_enter(id, stat)


def read_data():
    global timer
    data = ser.readline()
    if data:
        timer = 0
        rec = data.decode('utf-8','ignore')
        dir_id_stat = rec.strip().split('|')
        print(dir_id_stat)
        try:
            alert(*dir_id_stat)
        except:
            print('Incorrect data!')
        root.after(100, read_data)
    else:
        timer += 1
        if timer == 30:
            alert_default()
        root.after(1000, read_data)

try:
    ser = serial.Serial(port, speed, timeout=0)
except serial.serialutil.SerialException:
    print('Incorrect port name!')


root = Tk()
root.attributes("-fullscreen", True)
button_dir1, button_dir2, button_img1, button_img2 = 0, 0, 0, 0
button_name1, button_name2, button_stat1, button_stat2 =  0, 0 ,0, 0
img1, img2, photo1, photo2 = 0, 0, 0, 0
frame_b1, frame_b2 = 0, 0
frame1, frame2, frame3, frame0, frame4 = 0, 0, 0, 0, 0
timer = 0
button_enter, button_exit, button_door, button_street_text, button_vorota = 0, 0, 0, 0, 0


name = "Thread Web"
my_thread = MyThreadWeb(name)
my_thread.start()
name = "Thread App"
my_thread = MyThreadApp(name)
my_thread.start()

root.mainloop()
