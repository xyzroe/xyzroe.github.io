#include "Wiegand.h"

unsigned long WIEGAND::_sysTick=0;
unsigned long WIEGAND::_lastWiegand=0;
int			  WIEGAND::_GateActive=0;    // 1 = Active A   --   2 = Active B  ----  3 = Active C

unsigned long WIEGAND::_cardTempA=0;
unsigned long WIEGAND::_codeA=0;
int 		  WIEGAND::_bitCountA=0;
int			  WIEGAND::_wiegandTypeA=0;

unsigned long WIEGAND::_cardTempB=0;
unsigned long WIEGAND::_codeB=0;
int 		  WIEGAND::_bitCountB=0;
int			  WIEGAND::_wiegandTypeB=0;




WIEGAND::WIEGAND()
{

}


unsigned long WIEGAND::getCode()
{
  switch (_GateActive) {
    case 1:
		return _codeA;
      break;
    case 2:
		return _codeB;
      break;
    default:
		return 0;
  }
}

int WIEGAND::getWiegandType()
{
  switch (_GateActive) {
    case 1:
		return _wiegandTypeA;
      break;
    case 2:
		return _wiegandTypeB;
      break;
    default:
		return 0;
  }

}

int WIEGAND::getGateActive()
{
	return _GateActive;
}

bool WIEGAND::available()
{
	return DoWiegandConversion();
}

void WIEGAND::begin(bool GateA, bool GateB)
{
	_sysTick=millis();
	_lastWiegand = 0;

	if (GateA == 1 )
	{
		_cardTempA = 0;
		_codeA = 0;
		_wiegandTypeA = 0;
		_bitCountA = 0;

		pinMode(D0PinA, INPUT_PULLUP);					// Set D0 pin as input
		pinMode(D1PinA, INPUT_PULLUP);					// Set D1 pin as input
		attachInterrupt(digitalPinToInterrupt(D0PinA), ReadD0A, FALLING);	// Hardware interrupt - high to low pulse
		attachInterrupt(digitalPinToInterrupt(D1PinA), ReadD1A, FALLING);	// Hardware interrupt - high to low pulse
	}

	if (GateB == 1 )
	{
		_cardTempB = 0;
		_codeB = 0;
		_wiegandTypeB = 0;
		_bitCountB = 0;

		pinMode(D0PinB, INPUT_PULLUP);					// Set D0 pin as input
		pinMode(D1PinB, INPUT_PULLUP);					// Set D1 pin as input
		attachInterrupt(digitalPinToInterrupt(D0PinB), ReadD0B, RISING);	// Hardware interrupt - high to low pulse
		attachInterrupt(digitalPinToInterrupt(D1PinB), ReadD1B, RISING);	// Hardware interrupt - high to low pulse
	}

//	Serial.print("GateA Enabled = ");
//	Serial.println(GateA);
//	Serial.print("GateB Enabled = ");
//	Serial.println(GateB);

}

void WIEGAND::ReadD0A ()
{
	_bitCountA++;				// Increament bit count for Interrupt connected to D0
		_cardTempA <<= 1;		// D0 represent binary 0, so just left shift card data
	_lastWiegand = _sysTick;	// Keep track of last wiegand bit received
}

void WIEGAND::ReadD1A()
{
	_bitCountA ++;				// Increment bit count for Interrupt connected to D1
		_cardTempA |= 1;			// D1 represent binary 1, so OR card data with 1 then
		_cardTempA <<= 1;		// left shift card data
	_lastWiegand = _sysTick;	// Keep track of last wiegand bit received
}


void WIEGAND::ReadD0B ()
{
	_bitCountB++;				// Increament bit count for Interrupt connected to D0
		_cardTempB <<= 1;		// D0 represent binary 0, so just left shift card data
	_lastWiegand = _sysTick;	// Keep track of last wiegand bit received
}

void WIEGAND::ReadD1B()
{
	_bitCountB ++;				// Increment bit count for Interrupt connected to D1
		_cardTempB |= 1;			// D1 represent binary 1, so OR card data with 1 then
		_cardTempB <<= 1;		// left shift card data
	_lastWiegand = _sysTick;	// Keep track of last wiegand bit received
}

unsigned long WIEGAND::GetCardId (unsigned long *codelow, char bitlength)
{
	unsigned long cardID=0;

	if (bitlength==26)								// EM tag
		cardID = (*codelow & 0x1FFFFFE) >>1;

	return cardID;
}

bool WIEGAND::DoWiegandConversion ()
{
	unsigned long cardIDA;
	unsigned long cardIDB;


	_sysTick=millis();
	if ((_sysTick - _lastWiegand) > 200)								// if no more signal coming through after 25ms
	{
		if ((_bitCountA>0) || (_bitCountB>0)) 	// bitCount for keypress=8, Wiegand 26=26, Wiegand 34=34
		{
      Serial.print("_bitCountA "); Serial.println(_bitCountA);
      Serial.print("_bitCountB "); Serial.println(_bitCountB);
    /*  if ((_bitCountA>26)) {
        _bitCountA = (_bitCountA)-((_bitCountA) - 26);
        _cardTempA >>= 1;
        _cardTempA <<= _bitCountA-26;
        cardIDA = GetCardId (&_cardTempA, _bitCountA);
        _wiegandTypeA=_bitCountA;
        _bitCountA=0;
        _cardTempA=0;
        _GateActive=1;
        _codeA=cardIDA;
        return true;
      }
			else */if ((_bitCountA==26)) 	// bitCount for keypress=8, Wiegand 26=26, Wiegand 34=34
			{
				_cardTempA >>= 1;			// shift right 1 bit to get back the real value - interrupt done 1 left shift in advance
					cardIDA = GetCardId (&_cardTempA, _bitCountA);
					_wiegandTypeA=_bitCountA;
					_bitCountA=0;
					_cardTempA=0;
					_GateActive=1;
					_codeA=cardIDA;
					return true;
			}
			else
			{
				// well time over 25 ms and bitCount !=8 , !=26, !=34 , must be noise or nothing then.
				_lastWiegand=_sysTick;
				_bitCountA=0;
				_cardTempA=0;
				_GateActive=0;
			}
				// fine controllo accesso A





				// inizio controllo accesso B
			/*if ((_bitCountB>26)) 	// bitCount for keypress=8, Wiegand 26=26, Wiegand 34=34
			{
				_bitCountB = (_bitCountB)-((_bitCountB) - 26);
        _cardTempB >>= 1;
        _cardTempB <<= _bitCountB-26;
        cardIDB = GetCardId (&_cardTempB, _bitCountB);
        _wiegandTypeB=_bitCountB;
        _bitCountB=0;
        _cardTempB=0;
        _GateActive=2;
        _codeB=cardIDB;
        return true;
      }
			else */if((_bitCountB==26))		// wiegand 26 or wiegand 34
				{
          _cardTempB >>= 1;
					cardIDB = GetCardId (&_cardTempB, _bitCountB);
					_wiegandTypeB=_bitCountB;
					_bitCountB=0;
					_cardTempB=0;
					_GateActive=2;
					_codeB=cardIDB;
					return true;
				}

			else
			{
				// well time over 25 ms and bitCount !=8 , !=26, !=34 , must be noise or nothing then.
				_lastWiegand=_sysTick;
				_bitCountB=0;
				_cardTempB=0;
				_GateActive=0;
			}

			// fine controllo accesso B


		return false;
		}
		else
		  return false;
	}
	else
		return false;
}
